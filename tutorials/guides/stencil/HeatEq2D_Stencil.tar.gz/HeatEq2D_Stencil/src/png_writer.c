#include "png_writer.h"

#include <stdlib.h>
#include <stdio.h>
int write_field(const char* filename, const float* field, const int size) {
  unsigned char* image = calloc((size + 2) * (size + 2) * 3, sizeof(unsigned char));
  // Max temerature, this marks the "hotest" part of the image
  const float max = 100.0;

  for (int i = 0; i < (size + 2); i++) {
    for (int j = 0; j < (size + 2); j++) {
      const int field_index = i * (size + 2) + j;
      int palette_index = (int) ((field[field_index] / max) * 255.0);
      if (palette_index >= palette_size) {
	palette_index = palette_size - 1;
      }
      unsigned int color = palette[palette_index];
      const int index = i * (size + 2) * 3 + 3 * j;
      image[index + 0] = color >> 16;
      image[index + 1] = color >> 8;
      image[index + 2] = color;
    }
  }
  const int res = lodepng_encode24_file(filename, image, size + 2, size + 2);
  free(image);
  return res;
}

