#pragma once

/**
* Utilities to write a heat field to a PNG
*/

#include "palette.h"
#include "utils/lodepng.h"

#ifdef __cplusplus
extern "C" {
#endif
// Write heat 'field' to 'filename'
int write_field(const char* filename, const float* field, const int size);
#ifdef __cplusplus
}
#endif
