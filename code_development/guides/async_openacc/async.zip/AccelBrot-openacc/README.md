# AccelBrot
Mandelbrot implementation for different accelerator directives (`OpenMP` and
`OpenAcc`). See the different branches for desired directive approach. The main
branch contains the serial version.

## Building
This project requires `meson` to build.

```bash
$ meson setup builddir
$ meson compile -C builddir
```

## Running
Run the executable with
```bash
# Use --help to show possible arguments
$ ./builddir/src/mandelbrot
```
